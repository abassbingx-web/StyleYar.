package com.styleyar.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 1001;
    private static final int TAKE_PHOTO = 1002;
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFFFAF8F4);
        getWindow().setNavigationBarColor(0xFFFAF8F4);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setupWebView();
    }

    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFFAF8F4);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(webView);
        try {
            webView.loadUrl("file:///android_asset/index.html");
        } catch (Exception e) {
            showFallback();
        }
    }

    private void showFallback() {
        String html = "<html dir='rtl'><body style='background:#faf8f4;font-family:sans-serif;padding:32px'><h1>استایل‌یار</h1><p>نسخه برنامه اجرا شد، اما صفحه داخلی بارگذاری نشد.</p><p>لطفاً برنامه را دوباره باز کنید.</p></body></html>";
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    public class Bridge {
        @JavascriptInterface public void pickImage() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(i, PICK_IMAGE);
        }

        @JavascriptInterface public void takePhoto() {
            if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, TAKE_PHOTO);
                return;
            }
            launchCamera();
        }

        @JavascriptInterface public void openUrl(String url) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception e) { Toast.makeText(MainActivity.this, "امکان باز کردن لینک وجود ندارد", Toast.LENGTH_SHORT).show(); }
        }
    }

    private void launchCamera() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, TAKE_PHOTO + 100);
        else Toast.makeText(this, "دوربین در دسترس نیست", Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == TAKE_PHOTO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
    }

    private void sendImage(String mime, byte[] bytes) {
        String base64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
        String js = "window.onNativeImageSelected && window.onNativeImageSelected('data:" + mime + ";base64," + base64 + "')";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_IMAGE && data.getData() != null) {
            try {
                Uri uri = data.getData();
                InputStream in = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                sendImage("image/jpeg", out.toByteArray());
            } catch (Exception e) { Toast.makeText(this, "خواندن تصویر انجام نشد", Toast.LENGTH_SHORT).show(); }
        } else if (requestCode == TAKE_PHOTO + 100 && data.getExtras() != null) {
            Bitmap b = (Bitmap) data.getExtras().get("data");
            if (b != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.JPEG, 85, out);
                sendImage("image/jpeg", out.toByteArray());
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
